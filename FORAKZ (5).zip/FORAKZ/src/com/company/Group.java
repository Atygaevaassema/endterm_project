package com.company;

import java.sql.SQLException;

public class Group {
    private int group_id;
    private String name;
    private String speciality;

    public Group(int group_id, String name, String speciality) {
        this.group_id = group_id;
        this.name = name;
        this.speciality = speciality;
    }

    public int getGroup_id() {
        return group_id;
    }

    public void setGroup_id(int group_id) {
        this.group_id = group_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    public void insert() throws SQLException {
        DatabaseConnection.execute("INSERT INTO groups (name, speciality) VALUES ('"+name+"','"+speciality+"')");
    }
}
