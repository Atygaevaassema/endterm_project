package com.company;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.Vector;

public class SelectMenu {
    public static void menu() throws SQLException {
        System.out.println("Select option: ");
        System.out.println("1. Get all students");
        System.out.println("2. Get all groups");
        System.out.println("3. Get all courses");
        System.out.println("4. Get all grades of student");
        System.out.println("5. Get avg of student");
        System.out.println("6. Get avg of group");
        System.out.println("7. Get all grades");
        System.out.println("0. Quit");

        int i = Integer.parseInt(new Scanner(System.in).nextLine());
        switch (i) {
            case 1: allStudents(); break;
            case 2: allGroups(); break;
            case 3: allCourses(); break;
            case 4: studentGrades(); break;
            case 5: avgGroup(); break;
            case 6: avgStudent(); break;
            case 7: allGrades(); break;
            case 0: return;
        }
        menu();
    }

    public static void allStudents() throws SQLException {
        ParserInterface.printAllStudents(Parser.getAllStudents());
    }

    public static void allGroups() throws SQLException {
        ParserInterface.printAllGroups(Parser.getAllGroups());
    }

    public static void allCourses() throws SQLException {
        ParserInterface.printAllCourses(Parser.getAllCourses());
    }

    public static void allGrades() throws SQLException {
        ParserInterface.printAllGrades(Parser.getAllGrades());
    }

    public static void studentGrades() throws SQLException {
        System.out.println("Enter student id: ");
        int i = Integer.parseInt(new Scanner(System.in).nextLine());
        ResultSet rs = DatabaseConnection.executeQuery("SELECT * FROM grades WHERE student_id = " + i);
        Vector<Grade> temp = new Vector<>();
        while (rs.next()) {
            temp.add(new Grade(rs.getInt(0), rs.getInt(1), rs.getInt(2), rs.getInt(3)));
        }
        ParserInterface.printAllGrades(temp);
    }

    public static void avgGroup() throws SQLException {
        System.out.println("Enter group id: ");
        int i = Integer.parseInt(new Scanner(System.in).nextLine());
        ResultSet rs = DatabaseConnection.executeQuery("SELECT avg(grade) FROM grades WHERE grade_id = " + i);
        rs.next();
        System.out.println("Average of group is: " + rs.getString(1));
    }

    public static void avgStudent() throws SQLException {
        System.out.println("Enter student id: ");
        int i = Integer.parseInt(new Scanner(System.in).nextLine());
        ResultSet rs = DatabaseConnection.executeQuery("SELECT avg(grade) FROM grades WHERE student_id = " + i);
        rs.next();
        System.out.println("Average of student is: " + rs.getString(1));
    }
}
