package com.company;

import java.sql.SQLException;
import java.util.Scanner;

public class Menu {
    public static void menu() throws SQLException {
        System.out.println("Select option: ");
        System.out.println("1. Get info");
        System.out.println("2. New student");
        System.out.println("3. New group");
        System.out.println("4. New course");
        System.out.println("5. New grade");
        System.out.println("0. Quit");
        int i = Integer.parseInt(new Scanner(System.in).nextLine());
        switch (i) {
            case 1: SelectMenu.menu(); break;
            case 2: newStudent(); break;
            case 3: newGroup(); break;
            case 4: newCourse(); break;
            case 5: newGrade(); break;
            case 6: return;
        }
        menu();
    }

    public static void newStudent() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter fullname: ");
        String fn = scanner.nextLine();
        System.out.println("Enter group id: ");
        String group_id = scanner.nextLine();

         new Student(0, fn, Integer.parseInt(group_id)).insert();
    }

    public static void newGroup() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter name: ");
        String name = scanner.nextLine();
        System.out.println("Enter speciality: ");
        String spec = scanner.nextLine();

        new Group(0, name, spec).insert();
    }

    public static void newCourse() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter name: ");
        String name = scanner.nextLine();

        new Course(0, name).insert();
    }

    public static void newGrade() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter student id: ");
        String student = scanner.nextLine();
        System.out.println("Enter course id: ");
        String course = scanner.nextLine();
        System.out.println("Enter grade: ");
        String grade = scanner.nextLine();

        new Grade(0, Integer.parseInt(student), Integer.parseInt(course), Integer.parseInt(grade)).insert();
    }


}
