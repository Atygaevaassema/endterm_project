package com.company;

import javax.xml.crypto.Data;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatabaseConnection {

    private static DatabaseConnection instance;
    private Connection connection;
    private String url = "jdbc:postgresql://localhost:5432/school1";


    private DatabaseConnection() throws SQLException {
        try {
            // Here we load the driver’s class file into memory at the runtime
            Class.forName("org.postgresql.Driver");

            // Establish the connection
            Connection con = DriverManager.getConnection(url, "postgres", "qwerty321");
            this.connection = con;

        } catch (Exception e) {
            System.out.println(e);
        }
    }


    public Connection getConnection() {
        return connection;
    }

    public static DatabaseConnection getInstance() throws SQLException {
        if (instance == null) {
            instance = new DatabaseConnection();
        } else if (instance.getConnection().isClosed()) {
            instance = new DatabaseConnection();
        }
        return instance;
    }

    public static ResultSet executeQuery(String query) throws SQLException {
        return DatabaseConnection.getInstance().getConnection().createStatement().executeQuery(query);
    }

    public static void execute(String query) throws SQLException {
        DatabaseConnection.getInstance().getConnection().createStatement().execute(query);
    }
}
