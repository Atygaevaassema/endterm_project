package com.company;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class Parser {
    public static Vector<Group> getAllGroups() throws SQLException {
        ResultSet rs = DatabaseConnection.executeQuery("SELECT * FROM groups");
        Vector<Group> temp = new Vector<>();
        while (rs.next()) {
            temp.add(new Group(rs.getInt(1), rs.getString(2), rs.getString(3)));
        }
        return temp;
    }

    public static Vector<Student> getAllStudents() throws SQLException {
        ResultSet rs = DatabaseConnection.executeQuery("SELECT * FROM student");
        Vector<Student> temp = new Vector<>();
        while (rs.next()) {
            temp.add(new Student(rs.getInt(1), rs.getString(2), rs.getInt(3)));
        }
        return temp;
    }

    public static Vector<Course> getAllCourses() throws SQLException {
        ResultSet rs = DatabaseConnection.executeQuery("SELECT * FROM course");
        Vector<Course> temp = new Vector<>();
        while (rs.next()) {
            temp.add(new Course(rs.getInt(1), rs.getString(2)));
        }
        return temp;
    }

    public static Vector<Grade> getAllGrades() throws SQLException {
        ResultSet rs = DatabaseConnection.executeQuery("SELECT * FROM grades");
        Vector<Grade> temp = new Vector<>();
        while (rs.next()) {
            temp.add(new Grade(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4)));
        }
        return temp;
    }
}
