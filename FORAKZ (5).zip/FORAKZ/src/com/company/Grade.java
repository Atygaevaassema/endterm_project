package com.company;

import java.sql.SQLException;

public class Grade {
    private int grade_id;
    private int student_id;
    private int course_id;
    private int grade;

    public Grade(int grade_id, int student_id, int group_id, int grade) {
        this.grade_id = grade_id;
        this.student_id = student_id;
        this.course_id = group_id;
        this.grade = grade;
    }

    public int getGrade_id() {
        return grade_id;
    }

    public void setGrade_id(int grade_id) {
        this.grade_id = grade_id;
    }

    public int getStudent_id() {
        return student_id;
    }

    public void setStudent_id(int student_id) {
        this.student_id = student_id;
    }

    public int getCourse_id() {
        return course_id;
    }

    public void setCourse_id(int course_id) {
        this.course_id = course_id;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public void insert() throws SQLException {
        DatabaseConnection.execute("INSERT INTO grades (student_id, course_id, grade) VALUES ('"+student_id+"','"+course_id+"','"+grade+"')");
    }
}
