package com.company;

import java.sql.SQLException;

public class Student {
    private int student_id;
    private String fullname;
    private int group_id;

    public Student(int student_id, String fullname, int group_id) {
        this.student_id = student_id;
        this.fullname = fullname;
        this.group_id = group_id;
    }

    public int getStudent_id() {
        return student_id;
    }

    public void setStudent_id(int student_id) {
        this.student_id = student_id;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public int getGroup_id() {
        return group_id;
    }

    public void setGroup_id(int group_id) {
        this.group_id = group_id;
    }

    public void insert() throws SQLException {
        DatabaseConnection.execute("INSERT INTO student (fullname, group_id) VALUES ('"+fullname+"','"+group_id+"')");
    }
}
