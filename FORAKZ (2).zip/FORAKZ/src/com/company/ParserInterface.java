package com.company;

import java.util.Vector;

public class ParserInterface {
    public static void printAllGroups(Vector<Group> vector) {
        System.out.println("Group list: ");
        for (Group x : vector) {
            System.out.println(x.getGroup_id() + ". " + x.getName() + " " + x.getSpeciality());
        }
    }

    public static void printAllCourses(Vector<Course> vector) {
        System.out.println("Course list: ");
        for (Course x : vector) {
            System.out.println(x.getCourse_id() + ". " + x.getName());
        }
    }

    public static void printAllStudents(Vector<Student> vector) {
        System.out.println("Course list: ");
        for (Student x : vector) {
            System.out.println(x.getStudent_id() + ". " + x.getFullname() + " | Group id: " + x.getGroup_id());
        }
    }

    public static void printAllGrades(Vector<Grade> vector) {
        System.out.println("Grade list: ");
        for (Grade x : vector) {
            System.out.println(
                    x.getGrade_id() +
                            ". Student id: " + x.getStudent_id() +
                            ", Course id: " + x.getCourse_id() +
                            ", Grade: " + x.getGrade()
            );
        }
    }
}
